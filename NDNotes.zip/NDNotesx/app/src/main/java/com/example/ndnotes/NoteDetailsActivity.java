package com.example.ndnotes;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.net.URL;

public class NoteDetailsActivity extends AppCompatActivity {

    EditText titleEditText,contentEditText;
    ImageButton saveNoteBtn, addPhoto, takePictureBtn, rotateBtn;
    TextView pageTitleTextView;
    String title,content,docId, image;
    boolean isEditMode = false;
    TextView deleteNoteTextViewBtn;
    ImageView imageView3;
    ScaleGestureDetector scaleGestureDetector;
    float scaleFactor = 1.0f;
    StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("images");
    Uri imageUri;
    String imageName;
    private static final int CAMERA_REQUEST_CODE = 1;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_details);

        imageView3 = findViewById(R.id.imageView3);
        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleListener());

        titleEditText = findViewById(R.id.notes_title_text);
        rotateBtn = findViewById(R.id.rotate_btn);
        contentEditText = findViewById(R.id.notes_content_text);
        saveNoteBtn = findViewById(R.id.save_note_btn);
        pageTitleTextView =findViewById(R.id.page_title);
        deleteNoteTextViewBtn =findViewById(R.id.delete_note_text_view_btn);
        addPhoto = findViewById(R.id.add_photo);
        takePictureBtn = findViewById(R.id.take_picture_btn);



        takePictureBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkSelfPermission(Manifest.permission.CAMERA)
                        !=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            CAMERA_REQUEST_CODE);
                }else {
                    openCamera();
                }
            }
        });

        imageView3.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                Drawable drawable = imageView3.getDrawable();
                if (drawable == null){
                    rotateBtn.setVisibility(View.INVISIBLE);
                }else {
                    rotateBtn.setVisibility(View.VISIBLE);
                }
            }
        });












        rotateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float curentRotation = imageView3.getRotation();
                imageView3.setRotation(curentRotation + 90);

            }


        });





        title = getIntent().getStringExtra("title");
        content = getIntent().getStringExtra("content");
        docId = getIntent().getStringExtra("docId");
        image = getIntent().getStringExtra("image");

        if(docId!=null && !docId.isEmpty()){
            isEditMode = true;
        }

        titleEditText.setText(title);
        contentEditText.setText(content);
//        Picasso.Builder builder = new Picasso.Builder(this);
//        builder.listener((picasso, uri, exception) -> Log.d("NoteDetail", "onCreate: " + exception.getMessage()));
//        builder.build().load(image).into(imageView3);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(image);
                    Bitmap bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    runOnUiThread(() -> imageView3.setImageBitmap(bitmap));
                } catch(IOException e) {
                    Log.d("NoteDetail", "exception : " + e.getMessage());
                }
            }
        }).start();



        if (isEditMode){
            pageTitleTextView.setText("Edit your note");
            deleteNoteTextViewBtn.setVisibility(View.VISIBLE);
        }

        addPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i,CAMERA_REQUEST_CODE);

            }
        });




        saveNoteBtn.setOnClickListener((v)->saveNote());

        deleteNoteTextViewBtn.setOnClickListener((V)-> deleteNoteFromFirebase());







    }


    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permission,
                                           @NonNull int[] grantResult){
        if (requestCode == CAMERA_REQUEST_CODE){
            if (grantResult[0]== PackageManager.PERMISSION_GRANTED){
                openCamera();
            }else{
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permission, grantResult);
    }

    private void openCamera(){
        ContentValues values= new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "new image");
        values.put(MediaStore.Images.Media.DESCRIPTION, "from camera");
        imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(cameraIntent, 100);
    }






    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return scaleGestureDetector.onTouchEvent(event);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

         if (requestCode==1 && resultCode == RESULT_OK && null !=data){
            imageUri = data.getData();
            String[] filepath = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(imageUri,filepath,null,null,null);
            cursor.moveToFirst();

            Log.d("DEBUG", "onActivityResult: aici 2");


            int columneIndex= cursor.getColumnIndex(filepath[0]);
            String picturepath = cursor.getString(columneIndex);
            cursor.close();

            try{
                Log.d("NoteDetail", "onActivityResult: " + picturepath);
                Bitmap bitmap = BitmapFactory.decodeFile(picturepath);
                Log.d("NoteDetail", "onActivityResult: " + bitmap);
                imageView3.setImageBitmap(BitmapFactory.decodeFile(picturepath));
            }catch (Exception e){
                Log.d("NoteDetail", "Exception: " + e.getMessage());
            }
            imageName=picturepath.substring(picturepath.lastIndexOf("/")+1);



         }

         if (requestCode == 100 && resultCode == RESULT_OK){
             imageView3.setImageURI(imageUri);
             String[] filepath = {MediaStore.Images.Media.DATA};
             Cursor cursor = getContentResolver().query(imageUri,filepath,null,null,null);
             cursor.moveToFirst();

             Log.d("DEBUG", "onActivityResult: aici 3");


             int columneIndex= cursor.getColumnIndex(filepath[0]);
             String picturepath = cursor.getString(columneIndex);
             cursor.close();

             try{
                 Log.d("NoteDetail", "onActivityResult: " + picturepath);
                 Bitmap bitmap = BitmapFactory.decodeFile(picturepath);
                 Log.d("NoteDetail", "onActivityResult: " + bitmap);
                 imageView3.setImageBitmap(BitmapFactory.decodeFile(picturepath));
             }catch (Exception e){
                 Log.d("NoteDetail", "Exception: " + e.getMessage());
             }
             imageName=picturepath.substring(picturepath.lastIndexOf("/")+1);

         }


    }






    void saveNote(){

        String noteTitle = titleEditText.getText().toString();
        String noteContent = contentEditText.getText().toString();
        if (noteTitle==null||noteTitle.isEmpty() ){
            titleEditText.setError("Title is required");
            return;
        }
        if(imageUri == null){
            Note note = new Note();
            note.setTitle(noteTitle);
            note.setContent(noteContent);
            note.setTimestamp(Timestamp.now());
            if(image == null){
                note.setImageLink("");
            }else{
                note.setImageLink(image);
            }
            saveNoteToFirebase(note);
        }else{
            storageRef.child(imageName).putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Log.d("NoteDetail", "onSuccess:" + taskSnapshot.getStorage().getName());
//                        pd.dismiss();
//                        Task<Uri> downloadUri = taskSnapshot.getStorage().getDownloadUrl();
                            taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String generatedFilePath = uri.toString();
                                    Log.d("NoteDetail", "onSuccess: Image" + generatedFilePath);
                                    Note note = new Note();
                                    note.setTitle(noteTitle);
                                    note.setContent(noteContent);
                                    note.setTimestamp(Timestamp.now());
                                    note.setImageLink(generatedFilePath);
                                    saveNoteToFirebase(note);
                                }
                            });

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d("NoteDetail", "onFailure: " + e.getMessage());
//                        pd.dismiss();
                        }
                    });
        }


    }


    void saveNoteToFirebase(Note note){
        DocumentReference documentReference;
        if (isEditMode){
            documentReference = Utitlity.getCollectionReferanceForNotes().document(docId);


        }else {

            documentReference = Utitlity.getCollectionReferanceForNotes().document();

        }

        Log.d("NoteDetail", "saveNoteToFirebase: ");
        documentReference.set(note).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    //Notes is add
                    Log.d("NoteDetail", "onComplete: ");
                    Utitlity.showToast(NoteDetailsActivity.this,"Note added successfully!");
                    finish();
                }else {
                    //Note is notadd
                    Log.d("NoteDetail", "not added : ");
                    Utitlity.showToast(NoteDetailsActivity.this,"Fail add note");

                }

            }
        });

    }

    void deleteNoteFromFirebase(){
        DocumentReference documentReference;
        documentReference = Utitlity.getCollectionReferanceForNotes().document(docId);
        documentReference.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    //Notes is deleted
                    Utitlity.showToast(NoteDetailsActivity.this,"Note deleted successfully!");
                    finish();
                }else {
                    //Note is notadd
                    Utitlity.showToast(NoteDetailsActivity.this,"Fail while deleting note");

                }

            }
        });

    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener{
        @Override
        public boolean onScale(@NonNull ScaleGestureDetector detector) {
            scaleFactor *= scaleGestureDetector.getScaleFactor();
            imageView3.setScaleX(scaleFactor);
            imageView3.setScaleY(scaleFactor);
            return true;
        }
    }




}
